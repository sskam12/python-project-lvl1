#!/usr/bin/env python
def hello():
    print("Welcome to the Brain Games!")
def main():
    hello()
if __name__ == '__main__':
    main()
